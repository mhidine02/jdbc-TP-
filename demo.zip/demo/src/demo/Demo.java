
package demo;

import beans.Site;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Demo {
    
    public static void save(Site s){
    String user = "root";
    String password = "" ;
    String url = "jdbc:mysql://localhost:3306/demo";
    Connection cn = null ;
    Statement st = null ;
    try{
        Class.forName("com.mysql.jdbc.Driver");
        cn = DriverManager.getConnection(url, user, password);
        st = cn.createStatement();
        String req = "insert into site values(null,' " + s.getNom() + " ')";
        st.executeUpdate(req);
        
    } catch(SQLException e){
    System.out.println("Erreur SQL");
    } catch (ClassNotFoundException ex ){
    System.out.println("Impossible de charger le driver ");
    }finally{
    try{
       st.close();
       cn.close();
    } catch (SQLException ex ){
    System.out.println("Impossible de liberer les reaaources");}
    }
    }
    public static void load(){
    String user = "root";
    String password = "" ;
    String url = "jdbc:mysql://localhost:3306/demo";
    Connection cn = null ;
    Statement st = null ;
    ResultSet rs = null ;
    try{
        Class.forName("com.mysql.jdbc.Driver");
        cn = DriverManager.getConnection(url, user, password);
        st = (Statement) cn.createStatement();
        String req = "select * from site" ;
        rs = st.executeQuery(req);
        while (rs.next()){
        System.out.println(rs.getInt(1) + " " +rs.getString(2));
        }
    } catch(SQLException e){
    System.out.println(e.getMessage());
    } catch (ClassNotFoundException ex ){
    System.out.println("Impossible de charger le driver ");
    }finally{
    try{
       st.close();
       cn.close();
    } catch (SQLException ex ){
    System.out.println("Impossible de liberer les reaaources");}
    }
    }
    public static void main(String[] args) {
        /*save(new Site("SAFI"));
        save(new Site("MARRAKECH"));
        save(new Site("EL Jadida "));
        save(new Site("TATA"));*/
        load();
        
    }
    
}
